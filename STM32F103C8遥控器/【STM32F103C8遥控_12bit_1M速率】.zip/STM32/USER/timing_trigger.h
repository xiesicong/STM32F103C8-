#ifndef _timer_h_
#define _timer_h_

#include "stm32f10x.h"


void timing_trigger_init(void);
    
#endif

