#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
	 
 

#define LED1 		PCout(13)
#define LED2 		PBout(14)
 
 

void LED_Init(void);//IO��ʼ��
	

#endif





